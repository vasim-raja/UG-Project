<?php
session_start();
 $d=date("Y-m-d");
			
$conn=mysql_connect("localhost","root","");
mysql_select_db("website");
$sql="select * from cart where username ='$_SESSION[username]'";
$result=mysql_query($sql,$conn);
while($row=mysql_fetch_array($result))
{
	$sql="INSERT INTO `website`.`order` (
 `username` ,
`pname` ,
`price` ,
`quantity` ,
`odate` ,
`status` 
)
VALUES (
 '$_SESSION[username]', '$row[pname]', '$row[price]', '$row[quantity]', '$d','processing'
);


";

mysql_query($sql,$conn);
	
}


$sql="delete from cart where username ='$_SESSION[username]'";
mysql_query($sql,$conn);


		header("location:home.php");
		
	

?>