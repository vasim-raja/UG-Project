<?php
session_start();
 
			
$conn=mysql_connect("localhost","root","");
mysql_select_db("website");
$sql="select * from user where username ='$_SESSION[username]'";
$result=mysql_query($sql,$conn);
while($row=mysql_fetch_array($result))
{
	$userid=$row[id];
}
if($_POST[cat]=="vegitable")
{

$sql="select * from vegitable where id ='$_POST[fid]'";
$result=mysql_query($sql,$conn);
while($row=mysql_fetch_array($result))
{
$pid=$row[id];
	$prodname=$row[name];
	$price=$row[price];
	$image=$row[image];
}	
}		
if($_POST[cat]=="meat")
{

$sql="select * from meat where id ='$_POST[mid]'";
$result=mysql_query($sql,$conn);
while($row=mysql_fetch_array($result))
{
	$prodname=$row[name];
	$price=$row[price];
	$pid=$row[id];
	$image=$row[image];
}	
}	
$sql="INSERT INTO `website`.`cart` (
`userid` ,
`username` ,
`pid` ,
`pname` ,
`price` ,
`quantity` ,
`image`
)
VALUES (
'$userid', '$_SESSION[username]', '$pid', '$prodname', '$price', '$_POST[quantity]','$image'
);

";

mysql_query($sql,$conn);
		
		header("location:cart.php");
		
	

?>