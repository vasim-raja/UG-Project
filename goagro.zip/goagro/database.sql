-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2020 at 06:07 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `website`
--
CREATE DATABASE `website` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `website`;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `userid` int(3) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pid` int(3) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `price` int(3) NOT NULL,
  `quantity` mediumint(4) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`userid`, `username`, `pid`, `pname`, `price`, `quantity`, `image`) VALUES
(6, 'SWETHA', 3, 'Mathi', 120, 2, 'products/fmathi.jpg'),
(6, 'SWETHA', 2, 'chicken', 180, 1, 'products/chickenmeat.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catid` int(2) NOT NULL auto_increment,
  `catname` varchar(100) NOT NULL,
  PRIMARY KEY  (`catid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catid`, `catname`) VALUES
(1, 'fish'),
(2, 'meat');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `subject`, `message`) VALUES
('deepa', 'd@gmail.com', 'feedback', 'good service'),
('rahul', 'rahul@gmail.com', 'About service', 'Good service and delivering fresh items');

-- --------------------------------------------------------

--
-- Table structure for table `fish`
--

CREATE TABLE `fish` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(4) NOT NULL,
  `quantity` int(3) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `fish`
--

INSERT INTO `fish` (`id`, `name`, `description`, `price`, `quantity`, `image`) VALUES
(1, 'karimeen', 'tasty fish', 340, 20, 'products/fkarimeen.jpg'),
(2, 'kilimeen', 'tasty fish with red color', 150, 23, 'products/fkilimeen.jpg'),
(3, 'Mathi', 'available in kerala ', 120, 60, 'products/fmathi.jpg'),
(4, 'Ayala', 'tasty fish with good flesh', 100, 50, 'products/fishayala.jpg'),
(5, 'Avoli', 'tasty fish with black color', 400, 60, 'products/fishavoli.jpg'),
(6, 'Chembally', 'everyone likes', 300, 60, 'products/fishchembally.jpg'),
(7, 'chemmeen', 'very expensive and tasty', 500, 46, 'products/fishchemmeen.jpg'),
(8, 'Choora', 'good', 200, 40, 'products/fishchoora.jpg'),
(9, 'Kaari', 'Medium taste', 100, 56, 'products/fishkaari.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `meat`
--

CREATE TABLE `meat` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `price` int(4) NOT NULL,
  `quantity` int(4) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `meat`
--

INSERT INTO `meat` (`id`, `name`, `description`, `price`, `quantity`, `image`) VALUES
(1, 'Beef', 'red meat', 280, 100, 'products/beefmeat.jpg'),
(2, 'chicken', 'differnt type available', 180, 300, 'products/chickenmeat.jpg'),
(3, 'Pork', 'tasty', 340, 59, 'products/porkmeat.jpg'),
(4, 'Duck', 'good', 400, 50, 'products/duckmeat.jpg'),
(5, 'Mutton', 'healthy meat', 400, 56, 'products/mutton.png');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `username` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `price` int(4) NOT NULL,
  `quantity` int(5) NOT NULL,
  `odate` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `oid` int(3) NOT NULL auto_increment,
  PRIMARY KEY  (`oid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`username`, `pname`, `price`, `quantity`, `odate`, `status`, `oid`) VALUES
('seena', 'kilimeen', 150, 1, '2020-01-28', 'confirm', 1),
('seena', 'chicken', 180, 3, '2020-01-28', 'confirm', 2),
('seena', 'chicken', 180, 1, '2020-01-28', 'processing', 3),
('seena', 'Mathi', 120, 1, '2020-01-28', 'processing', 4),
('seena', 'Pork', 340, 3, '2020-01-28', 'processing', 5),
('jojo', 'chemmeen', 500, 1, '2020-01-29', 'processing', 6),
('jojo', 'Pork', 340, 1, '2020-01-29', 'processing', 7),
('jojo', 'Duck', 400, 1, '2020-01-29', 'confirm', 8);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(3) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `gender`, `email`, `contact`, `username`, `password`, `address`) VALUES
(1, 'test', 'male', 'test@gmail.com', '8877667788', 'test', '12345', ''),
(2, 'seena', 'female', 'seena@gmail.com', '99778886677', 'seena', '12345', ''),
(5, 'Jo', 'male', 'jo@gmail.com', '8800998800', 'jojo', 'jojo', ''),
(6, 'SWETHA', 'female', 'tyu@gmail.com', '8877997788', 'SWETHA', '12345', 'calicut');
