<?php

$conn=mysql_connect("localhost","root","");
mysql_select_db("website");

$sql="INSERT INTO `website`.`user` (
 `id` ,
`name` ,
`gender` ,
`email` ,
`contact` ,
`username` ,
`password` ,
`address` 
)
VALUES (
 NULL , '$_POST[name]', '$_POST[gender]', '$_POST[email]', '$_POST[contact]', '$_POST[username]', '$_POST[password]','$_POST[address]'
);
";

$result=mysql_query($sql,$conn);
		
		header("location:login.php");
		
	

?>