<?php

			
$conn=mysql_connect("localhost","root","");
mysql_select_db("website");
$sql="UPDATE `website`.`order` SET `status` = 'confirm' WHERE `order`.`oid` ='$_GET[oid]' LIMIT 1 ;";
mysql_query($sql,$conn);

		header("location:orders.php");
		
	

?>