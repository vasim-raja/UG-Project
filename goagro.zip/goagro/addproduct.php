<?php
$imgname=$_FILES["image"]["name"];
$imgtemp=$_FILES["image"]["tmp_name"];
$imgtype=$_FILES["image"]["type"];
$target_path = "products/".$imgname;
move_uploaded_file($imgtemp, $target_path);

$conn=mysql_connect("localhost","root","");
mysql_select_db("website");

if($_POST[cat]=="vegitable")
{
$sql="INSERT INTO `website`.`vegitable` (
`id` ,
`name` ,
`description` ,
`price` ,
`quantity` ,
`image` 
)
VALUES (
NULL, '$_POST[name]', '$_POST[description]', '$_POST[price]', '$_POST[quantity]', '$target_path'
);

";

mysql_query($sql,$conn);
}


if($_POST[cat]=="meat")
{
$sql="INSERT INTO `website`.`meat` (
`id` ,
`name` ,
`description` ,
`price` ,
`quantity` ,
`image` 
)
VALUES (
NULL, '$_POST[name]', '$_POST[description]', '$_POST[price]', '$_POST[quantity]', '$target_path'
);

";

mysql_query($sql,$conn);
}




		
		header("location:newproduct.php");
		
	

?>