<?php


$conn=mysql_connect("localhost","root","");
mysql_select_db("website");

$sql="INSERT INTO `website`.`feedback` (
 `name` ,
`email` ,
`subject` ,
`message` 
)
VALUES (
'$_POST[name]', '$_POST[email]', '$_POST[subject]', '$_POST[message]'
);
";

$result=mysql_query($sql,$conn);
		
		header("location:index.html");
		
	

?>